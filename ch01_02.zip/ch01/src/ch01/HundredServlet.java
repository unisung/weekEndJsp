package ch01;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/HundredServlet")
public class HundredServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, 
			 HttpServletResponse response) throws ServletException, IOException {
 
				int total=0;
				for(int cnt=1;cnt<101;cnt++) {
					total+=cnt;//total=total+cnt;
				}
				 //출력
				response.setContentType("text/html; charset=UTF-8");
				PrintWriter out = response.getWriter();
				out.print("<html><body><h1>Hundred Servlet</h1>");
				out.printf("1+2+3+...+100=%d",total);
				out.print("</body></html>");
				//자원해제
				out.close();
		
	}
}
