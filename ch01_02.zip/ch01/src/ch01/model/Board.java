package ch01.model;

public class Board {
	//필드
	private String title ;
	private String name;
	private String content;
	//생성자
	public Board(String title, String name, String content) {
		super();
		this.title = title;
		this.name = name;
		this.content = content;
	}
	//메소드
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

	//정보출력메소드
	@Override
	public String toString() {
		return "Board [title=" + title + ", name=" + name + ", content=" + content + "]";
	}
	
	
}
